import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.text.Collator;

public class DosesAplicadas {
    Scanner in = new Scanner(System.in);
    
    
    ArrayList<String> lista = new ArrayList<String>();


    public ArrayList<String> all(){

        ArrayList<String> all = new ArrayList<String>();
        String linha;

        try{
            
            File arquivoCSV = new File("C:\\Tp2 Java\\20220525_vacinometro.csv");
            BufferedReader br = new BufferedReader(new FileReader(arquivoCSV));
    
                //Lê as linhas do arquivo enquanto não forem nulas e as separa em um Array, o valor na posição [1] do array é o nome da dose, que é colocado em uma lista, se estiver vazia
                if(all.isEmpty()){
                    while ((linha = br.readLine()) != null) {
    
                        String[] colunas = linha.split(";");
    
                        if (colunas[0] != null && colunas[1] != null && colunas[2] != null){
                            all.add(colunas[0]);
                            all.add(colunas[1]);
                            all.add(colunas[2]);
                        }
                    }
                }
                
                br.close();

            }catch(FileNotFoundException e){
                System.out.println("Arquivo não encontrado");
            }catch(IOException e){
                System.out.println("Erro de leitura/escrita");
            }
            return all;
    }


    public ArrayList<String> atualizaCidade(String cidade,String tipoDose){

        boolean validador = true;
        String numDoseS;
        int numDose = 0;
        String linha;
        ArrayList<String> all = new ArrayList<String>();

        try{
        File arquivoCSV = new File("C:\\Tp2 Java\\20220525_vacinometro.csv");
        BufferedReader br = new BufferedReader(new FileReader(arquivoCSV));

            //Lê as linhas do arquivo enquanto não forem nulas e as separa em um Array, o valor na posição [1] do array é o nome da dose, que é colocado em uma lista, se estiver vazia
            if(lista.isEmpty()){
                while ((linha = br.readLine()) != null) {

                    String[] colunas = linha.split(";");

                    if (colunas[0] != null && colunas[1] != null && colunas[2] != null){
                        all.add(colunas[0]);
                        all.add(colunas[1]);
                        all.add(colunas[2]);
                    }

                    //Acho que seria possível fazer isso com índices, similar a banco de dados, nos dados das tabelas e organizar elas, mas não sei como faria.
                    for(int i = 0; i < lista.size()-2;i+=2){
                        if(lista.get(i).equalsIgnoreCase(cidade) && lista.get(i+1).equalsIgnoreCase(tipoDose)){
                                System.out.printf("O número atual de doses dessa cidade é %s, para qual número deseja atualizar? : ",lista.get(i+2));
                                while(validador){
                                    try{
                                    numDose = in.nextInt();
                                    }catch(InputMismatchException e){
                                        System.out.println("Por favor, digite um número válido! :");
                                    }
                                    if (numDose > 0){
                                        validador = false;
                                    }
                                }
                                numDoseS = "" + numDose;
                                lista.set(i+2,numDoseS);
                            }else{
                                System.out.println("Erro!");
                            }
                    }
                }
            }

        }catch(FileNotFoundException e){
            System.out.println("Arquivo não encontrado");
        }catch(IOException e){
            System.out.println("Erro de leitura/escrita");
        }


        return lista;
    }

}