import java.util.Scanner;


public class teste{
public static void main(String args[]) {
    
Scanner in = new Scanner(System.in);
int x;
String y;

x = in.nextInt();





}
}

