import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.text.Collator;


public class Main {

    public static void main(String args[]) {
    
        //Define o caminho
        Scanner in = new Scanner(System.in);
        Cidade cidade = new Cidade();
        TipoDose dose = new TipoDose();
        DosesAplicadas aplicadas = new DosesAplicadas();
        Boolean validador = true;
        ArrayList<String> lista = new ArrayList<String>();
        ArrayList<String> listaGeral = new ArrayList<String>();
        ArrayList<String> listaDose = new ArrayList<String>();
        listaGeral = aplicadas.all();
        listaDose = dose.listarDose();



        while(validador){

            System.out.println("O que deseja fazer? \n [1] - Cadastrar cidade\n [2] - Visualizar cidades\n [3] - Cadastrar Dose\n [4] - Visualizar Doses \n [5] - Atualizar número de doses\n [6] - Exibir Tudo\n [0] - Sair do Programa ");
            int decisao = in.nextInt();
    
            switch (decisao){
                case 1:
                
                    cidade.cadastrarCidade();
                    break;

                case 2:

                    lista = cidade.listarCidade();

                    //Imprime as cidades da lista sem duplicatas

                    for (int i = 0; i < lista.size() ; i++){
                        System.out.println(lista.get(i));
                    }

                    break;
                
                case 3:

                    dose.cadastroDose();
                    break;

                case 4:
                    
                    lista = dose.listarDose();

                    //Imprime as doses da lista sem duplicatas

                    for (int i = 0; i < lista.size() ; i++){
                        System.out.println(lista.get(i));
                    }
                    break;

                case 5:
                    
                    String cid, dosecid;
                    int val = 0, j = 0;
                    System.out.println("Qual cidade?: ");
                    cid = in.nextLine();
                    
                    for (int i = 0; listaDose.size()-1;i++){
                        System.out.println();
                    }
                    System.out.println("Dose ?: ");
                    dosecid = in.nextLine();

                    for (int i = 0; i < listaGeral.size()-3;i++){
                        if (cid.equalsIgnoreCase(listaGeral.get(i)) && dosecid.equalsIgnoreCase(listaGeral.get(i+1))){
                            val++;
                        }
                    }

                    if (val>1){
                        aplicadas.atualizaCidade(cid,dosecid);
                    }else{
                        System.out.println("Cidade não cadastrada!");
                    }

                    break;
                
                case 6:

                    //A partir da listaGeral, que possui TODOS os dados em ordem de Cidade,Tipo de dose e Quantidade, exibe a cidade, o proximo valor e o próximo a esse, e então pula 3 valores no i, que representa a próxima cidade, e repete o processo.
                    for(int i = 0; i < listaGeral.size()-2; i+=3){
                        System.out.printf("Cidade: %s  Dose: %s  Quantidade: %s\n",listaGeral.get(i),listaGeral.get(i+1),listaGeral.get(i+2));
                    }

                    break;

                case 0:
                    System.out.println("\nObrigado! Feito por Juliano Barreira Zorzetto - 2° Ciclo ADS - Vespertino");
                    validador = false;
                    break;
            }
        }

        in.close();

        
    }
}

